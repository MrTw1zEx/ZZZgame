
if (typeof gdjs.evtsExt__SwipeGesture__SwipeDirection_8way !== "undefined") {
  gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__SwipeGesture__SwipeDirection_8way = {};


gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() >= -(112.5));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() < -(67.5));
}
}
if (isConditionTrue_0) {
{eventsFunctionContext.returnValue = true;}}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.getArgument("Direction") == "Up");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList0(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList2 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() >= 67.5);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() < 112.5);
}
}
if (isConditionTrue_0) {
{eventsFunctionContext.returnValue = true;}}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList3 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.getArgument("Direction") == "Down");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList2(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList4 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() >= -(180));
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() < -(157.5));
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() >= 157.5);
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() < 180);
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
{eventsFunctionContext.returnValue = true;}}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList5 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.getArgument("Direction") == "Left");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList4(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList6 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() >= -(22.5));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() < 22.5);
}
}
if (isConditionTrue_0) {
{eventsFunctionContext.returnValue = true;}}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList7 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.getArgument("Direction") == "Right");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList6(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList8 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() >= -(67.5));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() < -(22.5));
}
}
if (isConditionTrue_0) {
{eventsFunctionContext.returnValue = true;}}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList9 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.getArgument("Direction") == "UpRight");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList8(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList10 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() >= -(157.5));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() < -(112.5));
}
}
if (isConditionTrue_0) {
{eventsFunctionContext.returnValue = true;}}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList11 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.getArgument("Direction") == "UpLeft");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList10(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList12 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() >= 112.5);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() < 157.5);
}
}
if (isConditionTrue_0) {
{eventsFunctionContext.returnValue = true;}}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList13 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.getArgument("Direction") == "DownLeft");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList12(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList14 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() >= 22.5);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.sceneVariablesForExtension.getFromIndex(9).getAsNumber() < 67.5);
}
}
if (isConditionTrue_0) {
{eventsFunctionContext.returnValue = true;}}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList15 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (eventsFunctionContext.getArgument("Direction") == "DownRight");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList14(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList16 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList1(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList3(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList5(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList7(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList9(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList11(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList13(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList15(runtimeScene, eventsFunctionContext);
}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList17 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList16(runtimeScene, eventsFunctionContext);
}


};gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList18 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__SwipeGesture__Distance.func(runtimeScene, eventsFunctionContext) > 0;
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList17(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};

gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.func = function(runtimeScene, Direction, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
},
  _objectArraysMap: {
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("SwipeGesture"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("SwipeGesture"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "Direction") return Direction;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};


gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.eventsList18(runtimeScene, eventsFunctionContext);


return !!eventsFunctionContext.returnValue;
}

gdjs.evtsExt__SwipeGesture__SwipeDirection_8way.registeredGdjsCallbacks = [];